export const buttonsData = [
  { title: "All", value: "all" },
  { title: "Veg", value: "veg" },
  { title: "Non-Veg", value: "non_veg" },
];

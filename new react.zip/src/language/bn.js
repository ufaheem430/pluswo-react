export const bengali = {
  "Checking theme and rtl": "থিম এবং আরটিএল পরীক্ষা করা হচ্ছে",
  "Light Mode": "হালকা মোড",
  "Location":"Location",
};

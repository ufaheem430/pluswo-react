export const google_client_id =
    "";
export const fb_app_id = "";
export const appleLoginCredential = {
  appleId: '',
  serviceId: '',
  privateKey: '',
  redirectURI:``
}
"use strict";
(() => {
var exports = {};
exports.id = 2222;
exports.ids = [2222,3983,6812,5405];
exports.modules = {

/***/ 45050:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cash-on-delivery.e342573b.svg","height":35,"width":36});

/***/ }),

/***/ 95230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/digitalpayment.c4061242.svg","height":35,"width":36});

/***/ }),

/***/ 75022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/image 45.43fe4b1e.svg","height":38,"width":38});

/***/ }),

/***/ 8636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/image 46.1fc067d7.svg","height":38,"width":38});

/***/ }),

/***/ 49805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/receiverimage.fb1a6fb2.svg","height":36,"width":36});

/***/ }),

/***/ 17904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/senderimage.3e11cc04.svg","height":36,"width":36});

/***/ }),

/***/ 99142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/wallet.30b2b50d.svg","height":30,"width":30});

/***/ }),

/***/ 86711:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ _index__WEBPACK_IMPORTED_MODULE_12__.getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13258);
/* harmony import */ var _src_components_checkout_parcel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71923);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _meta_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74121);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _src_components_route_guard_AuthGuard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46941);
/* harmony import */ var _src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97215);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _src_helper_functions_getCartListModuleWise__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(58345);
/* harmony import */ var _src_components_checkout_Prescription__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(64238);
/* harmony import */ var _custom_no_ssr__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(52588);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(44369);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_2__, _src_components_checkout_parcel__WEBPACK_IMPORTED_MODULE_3__, _src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__, _src_components_checkout_Prescription__WEBPACK_IMPORTED_MODULE_10__, _index__WEBPACK_IMPORTED_MODULE_12__]);
([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_2__, _src_components_checkout_parcel__WEBPACK_IMPORTED_MODULE_3__, _src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__, _src_components_checkout_Prescription__WEBPACK_IMPORTED_MODULE_10__, _index__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const CheckOutPage = ({ configData , landingPageData  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { page , store_id , id  } = router.query;
    const { cartList: aliasCartList , campaignItemList , buyNowItemList , totalAmount  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)((state)=>state.cart);
    const cartList = (0,_src_helper_functions_getCartListModuleWise__WEBPACK_IMPORTED_MODULE_13__/* .getCartListModuleWise */ .l)(aliasCartList);
    const handleRouteRedirect = ()=>{
        if (false) {}
    };
    const handleEmpty = ()=>{
        if (router.isReady) {
            if (page === "cart" && cartList.length === 0) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_no_ssr__WEBPACK_IMPORTED_MODULE_11__["default"], {
                    children: handleRouteRedirect()
                });
            } else if (page === "campaign" && campaignItemList.length === 0) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_no_ssr__WEBPACK_IMPORTED_MODULE_11__["default"], {
                    children: handleRouteRedirect()
                });
            } else if (!page) {
                router.push("/home", undefined, {
                    shallow: true
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_4___default()), {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_meta_data__WEBPACK_IMPORTED_MODULE_5__["default"], {
                title: `Checkout - ${configData?.business_name}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                configData: configData,
                landingPageData: landingPageData,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_components_route_guard_AuthGuard__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    from: "checkout",
                    children: [
                        page === "parcel" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_checkout_parcel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                        page === "prescription" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_checkout_Prescription__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            storeId: store_id
                        }),
                        page === "campaign" && campaignItemList.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            router: router,
                            configData: configData,
                            page: page,
                            cartList: cartList,
                            campaignItemList: campaignItemList,
                            totalAmount: totalAmount
                        }),
                        page === "cart" && cartList.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            router: router,
                            configData: configData,
                            page: page,
                            cartList: cartList,
                            campaignItemList: campaignItemList,
                            totalAmount: totalAmount
                        }),
                        page === "buy_now" && buyNowItemList.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_checkout_item_checkout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            router: router,
                            configData: configData,
                            page: page,
                            cartList: buyNowItemList,
                            campaignItemList: campaignItemList,
                            totalAmount: totalAmount
                        }),
                        handleEmpty()
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckOutPage);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const CustomNoSsr = ({ children  })=>{
    const [isClient, setIsClient] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setIsClient(true);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isClient && children
    });
};
CustomNoSsr.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomNoSsr);


/***/ }),

/***/ 77278:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ CouponApi)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__]);
_MainApi__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CouponApi = {
    couponList: ()=>_MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/coupon/list"),
    applyCoupon: (code, store_id)=>_MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/coupon/apply?code=${code}&store_id=${store_id}`)
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 84379:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ ProfileApi)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__]);
_MainApi__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const ProfileApi = {
    profileInfo: ()=>_MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/customer/info"),
    profileUpdate: (profileData)=>_MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/update-profile", profileData)
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 36498:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetDistance)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(67759);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__, _MainApi__WEBPACK_IMPORTED_MODULE_2__]);
([_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__, _MainApi__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getDistance = async (origin, destination)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .distance_api */ .N5}?origin_lat=${origin?.lat}&origin_lng=${origin?.lng}&destination_lat=${destination.lat ? destination.lat : destination?.latitude}&destination_lng=${destination.lng ? destination.lng : destination?.longitude}&mode=walking`);
    return data;
};
function useGetDistance(origin, destination) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "distance",
        origin,
        destination
    ], ()=>getDistance(origin, destination), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__/* .onSingleErrorResponse */ .f
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8142:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetVehicleCharge)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getData = async (pageParams)=>{
    const { tempDistance  } = pageParams;
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`/api/v1/vehicle/extra_charge?distance=${tempDistance}`);
    return data;
};
function useGetVehicleCharge(pageParams) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("vehicle", ()=>getData(pageParams), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 74093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ useOrderPlace)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60274);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__]);
_MainApi__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const orderPlace = async (orderData)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .order_place_api */ .jv}`, orderData);
    return data;
};
const useOrderPlace = ()=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useMutation)("order-place", orderPlace);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetStoreDetails)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getData = async (store_id)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .store_details_api */ .HR}/${store_id}`);
    return data;
};
function useGetStoreDetails(store_id) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)("store-details", ()=>getData(store_id), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 43041:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48125);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Fade__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45634);
/* harmony import */ var _mui_material_Fade__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Fade__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57987);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45048);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowDown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(37236);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowDown__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardDoubleArrowDown__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
react_i18next__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const ItemSelectWithChip = (props)=>{
    const { title , data , handleChange  } = props;
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1__.useState(null);
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const handleClickItem = (value)=>{
        setSelected(value);
        setAnchorEl(null);
        handleChange?.(value);
    };
    const handleDelete = ()=>{
        setSelected(null);
        handleChange?.(null);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomBoxFullWidth */ .uu, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                id: "fade-button",
                "aria-controls": open ? "fade-menu" : undefined,
                "aria-haspopup": "true",
                "aria-expanded": open ? "true" : undefined,
                onClick: handleClick,
                fullWidth: true,
                sx: {
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center"
                },
                children: [
                    t(title),
                    open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardDoubleArrowDown__WEBPACK_IMPORTED_MODULE_9___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_8___default()), {})
                ]
            }),
            data?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_3___default()), {
                id: "fade-menu",
                MenuListProps: {
                    "aria-labelledby": "fade-button"
                },
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                TransitionComponent: (_mui_material_Fade__WEBPACK_IMPORTED_MODULE_5___default()),
                children: data?.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>handleClickItem(item),
                        children: t(item)
                    }, index);
                })
            }),
            selected && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_10__.Chip, {
                sx: {
                    mt: "10px",
                    ml: "15px"
                },
                label: t(selected),
                onDelete: handleDelete
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItemSelectWithChip);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 67982:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _checkout_CheckOut_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66366);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _CustomDivider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35740);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(81261);
/* harmony import */ var _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(89113);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8142);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_9__]);
([i18next__WEBPACK_IMPORTED_MODULE_5__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const PrescriptionOrderCalculation = ({ storeData , configData , distanceData , orderType , zoneData , origin , destination , totalOrderAmount , deliveryTip  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const tempDistance = distanceData?.data?.rows?.[0]?.elements[0]?.distance?.value / 1000;
    const { data: extraCharge , refetch: extraChargeRefetch  } = (0,_api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)({
        tempDistance
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        extraChargeRefetch();
    }, [
        distanceData
    ]);
    const getPrescriptionDeliveryFees = (storeData, configData, distance, orderType, zoneData, origin, destination)=>{
        let convertedDistance = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .handleDistance */ .NY)(distance?.rows?.[0]?.elements, origin, destination);
        let deliveryFee = convertedDistance * configData?.per_km_shipping_charge;
        //checking if latest codes are there at github
        //restaurant self delivery system checking
        if (Number.parseInt(storeData?.self_delivery_system) === 1) {
            if (storeData?.free_delivery) {
                return 0;
            } else {
                deliveryFee = convertedDistance * storeData?.per_km_shipping_charge || 0;
                if (deliveryFee > storeData?.minimum_shipping_charge && deliveryFee < storeData.maximum_shipping_charge) {
                    return deliveryFee;
                } else {
                    if (deliveryFee < storeData?.minimum_shipping_charge) {
                        return storeData?.minimum_shipping_charge;
                    } else if (storeData?.maximum_shipping_charge !== null && deliveryFee > storeData?.maximum_shipping_charge) {
                        return storeData?.maximum_shipping_charge;
                    }
                }
            }
        } else {
            if (zoneData?.data?.zone_data?.length > 0) {
                const chargeInfo = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getInfoFromZoneData */ .PR)(zoneData);
                if (chargeInfo?.pivot?.per_km_shipping_charge) {
                    deliveryFee = convertedDistance * (chargeInfo?.pivot?.per_km_shipping_charge || 0);
                    if (deliveryFee < chargeInfo?.pivot?.minimum_shipping_charge) {
                        return chargeInfo?.pivot?.minimum_shipping_charge + extraCharge;
                    } else if (deliveryFee > chargeInfo?.pivot?.maximum_shipping_charge && chargeInfo?.pivot?.maximum_shipping_charge !== null) {
                        return chargeInfo?.pivot?.maximum_shipping_charge + extraCharge;
                    } else {
                        if (configData?.free_delivery_over !== null && configData?.free_delivery_over > 0 && totalOrderAmount > configData?.free_delivery_over || orderType === "take_away") {
                            return 0;
                        } else {
                            return deliveryFee + extraCharge;
                        }
                    }
                }
            }
        }
    };
    const handleTotalAmount = ()=>{
        const totalAmount = getPrescriptionDeliveryFees(storeData, configData, distanceData?.data, orderType, zoneData, origin, destination) + Number(deliveryTip);
        localStorage.setItem("totalAmount", totalAmount);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
            color: theme.palette.primary.main,
            children: storeData && (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__/* .getAmountWithSign */ .B9)(totalAmount)
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_checkout_CheckOut_style__WEBPACK_IMPORTED_MODULE_2__/* .CalculationGrid */ .M0, {
        container: true,
        item: true,
        md: 12,
        xs: 12,
        spacing: 1,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                md: 8,
                xs: 8,
                children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Deliveryman tips")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                md: 4,
                xs: 4,
                align: "right",
                children: (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__/* .getAmountWithSign */ .B9)(deliveryTip)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                md: 8,
                xs: 8,
                children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Delivery fee")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                md: 4,
                xs: 4,
                align: "right",
                children: storeData && (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_7__/* .getAmountWithSign */ .B9)(getPrescriptionDeliveryFees(storeData, configData, distanceData?.data, orderType, zoneData, origin, destination))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomDivider__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_checkout_CheckOut_style__WEBPACK_IMPORTED_MODULE_2__/* .TotalGrid */ .v5, {
                container: true,
                md: 12,
                xs: 12,
                mt: "1rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        md: 8,
                        xs: 8,
                        pl: ".5rem",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                            fontWeight: "bold",
                            color: theme.palette.primary.main,
                            children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Total")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        md: 4,
                        xs: 4,
                        align: "right",
                        children: handleTotalAmount()
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PrescriptionOrderCalculation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 32631:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _checkout_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66366);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22021);
/* harmony import */ var _multi_file_uploader_MultiFileUploader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17787);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_4__, _multi_file_uploader_MultiFileUploader__WEBPACK_IMPORTED_MODULE_5__]);
([i18next__WEBPACK_IMPORTED_MODULE_4__, _multi_file_uploader_MultiFileUploader__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const acceptedFileInputFormat = "application/pdf,image/*,text/plain,.doc, .docx,.txt";
const supportedFormatMultiImages = [
    "jpg",
    "jpeg",
    "gif",
    "png",
    "pdf",
    "doc",
    "docx",
    "deb"
];
const PrescriptionUpload = ({ setPrescriptionImages , prescriptionImages  })=>{
    const fileImagesHandler = (files)=>{
        setPrescriptionImages(files);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomPaperBigCard */ .iD, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkout_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .DeliveryCaption */ .qv, {
                const: true,
                id: "demo-row-radio-buttons-group-label",
                children: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("Prescriptions")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_multi_file_uploader_MultiFileUploader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                fileImagesHandler: fileImagesHandler,
                totalFiles: prescriptionImages,
                maxFileSize: 20000000,
                supportedFileFormats: supportedFormatMultiImages,
                acceptedFileInputFormat: acceptedFileInputFormat,
                labelText: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("File Upload"),
                prescription: "true"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PrescriptionUpload);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 96542:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45269);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var _DeliveryFree__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4210);
/* harmony import */ var _DeliveryManTip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(26139);
/* harmony import */ var _ChangePayBy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__, _DeliveryFree__WEBPACK_IMPORTED_MODULE_6__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_7__, _ChangePayBy__WEBPACK_IMPORTED_MODULE_8__]);
([i18next__WEBPACK_IMPORTED_MODULE_5__, _DeliveryFree__WEBPACK_IMPORTED_MODULE_6__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_7__, _ChangePayBy__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Billing = ({ deliveryTip , setDeliveryTip , paidBy , setPaidBy , data , parcelDeliveryFree , zoneData , senderLocation , receiverLocation , configData  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomPaperBigCard */ .iD, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw, {
            spacing: 4,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                    align: "center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                        variant: "h6",
                        children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Billing")
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryFree__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: data,
                    parcelDeliveryFree: parcelDeliveryFree,
                    senderLocation: senderLocation,
                    receiverLocation: receiverLocation,
                    configData: configData
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryManTip__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    deliveryTip: deliveryTip,
                    setDeliveryTip: setDeliveryTip
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChangePayBy__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    paidBy: paidBy,
                    setPaidBy: setPaidBy,
                    zoneData: zoneData
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Billing);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1197:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77591);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22021);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58861);
/* harmony import */ var _public_static_senderimage_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(17904);
/* harmony import */ var _public_static_receiverimage_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(49805);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_4__]);
i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const ChangePayBy = ({ paidBy , setPaidBy , zoneData  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        spacing: 1.1,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomTypography */ .ZT, {
                    fontWeigh: "500",
                    children: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("Charge Paid By")
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                spacing: 4,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                        spacing: 0.5,
                        sx: {
                            cursor: "pointer"
                        },
                        onClick: ()=>setPaidBy("sender"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                backgroundColor: paidBy === "sender" && (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.primary.main, 0.1),
                                sx: {
                                    borderRadius: "15px"
                                },
                                padding: "14px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    src: _public_static_senderimage_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"].src */ .Z.src,
                                    height: "36px",
                                    width: "36px",
                                    objectfit: "contain"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                align: "center",
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("Sender")
                            })
                        ]
                    }),
                    zoneData?.data?.zone_data?.[0]?.cash_on_delivery && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                        spacing: 0.5,
                        onClick: ()=>setPaidBy("receiver"),
                        sx: {
                            cursor: "pointer"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                //selected={paidBy === "receiver"}
                                backgroundColor: paidBy === "receiver" && (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.alpha)(theme.palette.primary.main, 0.1),
                                sx: {
                                    borderRadius: "15px"
                                },
                                padding: "14px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    src: _public_static_receiverimage_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"].src */ .Z.src,
                                    height: "36px",
                                    width: "36px",
                                    objectfit: "contain"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                align: "center",
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("Receiver")
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangePayBy);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4210:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58861);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22021);
/* harmony import */ var _public_static_image_45_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(75022);
/* harmony import */ var _public_static_image_46_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8636);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(89113);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(81261);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_6__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_10__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__]);
([i18next__WEBPACK_IMPORTED_MODULE_6__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_10__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const DeliveryFree = ({ data , parcelDeliveryFree , senderLocation , receiverLocation , configData  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        justifyContent: "center",
        alignItems: "center",
        direction: "row",
        spacing: 4,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                direction: "row",
                width: "100%",
                spacing: 1.5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        src: _public_static_image_45_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"].src */ .Z.src,
                        width: "37px",
                        height: "37px",
                        objectfit: "contain"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                color: theme.palette.neutral[1000],
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Distance")
                            }),
                            data ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                color: theme.palette.primary.main,
                                fontWeight: "600",
                                children: [
                                    (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__/* .handleDistance */ .NY)(data?.rows[0]?.elements, senderLocation, receiverLocation)?.toFixed(configData?.digit_after_decimal_point),
                                    " ",
                                    "km"
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Skeleton, {
                                width: 50,
                                height: 20,
                                variant: "text"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                direction: "row",
                width: "100%",
                spacing: 1.5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        src: _public_static_image_46_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"].src */ .Z.src,
                        width: "37px",
                        height: "37px",
                        objectfit: "contain"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        flexWrap: "wrap",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Delivery Fee")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                color: theme.palette.primary.main,
                                fontWeight: "600",
                                children: (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_10__/* .getAmountWithSign */ .B9)(parcelDeliveryFree())
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryFree);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 15245:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(50550);
/* harmony import */ var _mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49426);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _DeliveryInfoCard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(66173);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58861);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _DeliveryInfoCard__WEBPACK_IMPORTED_MODULE_9__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _DeliveryInfoCard__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const DeliveryInfo = ({ parcelInfo , configData  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomPaperBigCard */ .iD, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
            spacing: 3,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                    align: "center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        variant: "h6",
                        children: t("Delivery Information")
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryInfoCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    title: t("Sender"),
                    phone: parcelInfo?.senderPhone,
                    name: parcelInfo?.senderName,
                    address: parcelInfo?.senderAddress
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryInfoCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    title: t("Receiver"),
                    phone: parcelInfo?.receiverPhone,
                    name: parcelInfo?.receiverName,
                    address: parcelInfo?.receiverAddress
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 0.5,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            width: "100%",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "500",
                                children: t("Parcel Category")
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            width: "100%",
                            padding: "1.3rem",
                            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.primary.main, 0.1),
                            borderRadius: "7px",
                            spacing: 2,
                            direction: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    width: "56px",
                                    height: "56px",
                                    src: `${configData?.base_urls?.parcel_category_image_url}/${parcelInfo?.image}`,
                                    objectfit: "contain"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                            variant: "h6",
                                            children: parcelInfo?.name
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                            color: theme.palette.neutral[500],
                                            children: parcelInfo?.description
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryInfo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66173:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50550);
/* harmony import */ var _mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49426);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_7__]);
i18next__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const DeliveryInfoCard = ({ title , name , phone , address  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
        spacing: 0.5,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                width: "100%",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                    fontWeight: "500",
                    children: title
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                width: "100%",
                padding: ".9rem",
                backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.alpha)(theme.palette.primary.main, 0.1),
                borderRadius: "7px",
                spacing: 0.5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                        children: name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        direction: "row",
                        spacing: 1.3,
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocalPhone__WEBPACK_IMPORTED_MODULE_4___default()), {
                                sx: {
                                    width: "16.5px",
                                    height: "16.5px",
                                    color: (theme)=>theme.palette.primary.main
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "14px",
                                color: theme.palette.neutral[500],
                                children: phone
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        direction: "row",
                        spacing: 1.3,
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_5___default()), {
                                sx: {
                                    width: "16.5px",
                                    height: "16.5px",
                                    color: (theme)=>theme.palette.primary.main
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "14px",
                                color: theme.palette.neutral[500],
                                children: address
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryInfoCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 26139:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_ArrowBackIos__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4195);
/* harmony import */ var _mui_icons_material_ArrowBackIos__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ArrowBackIos__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(66366);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const DeliveryManTip = ({ deliveryTip , setDeliveryTip  })=>{
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [fieldValue, setFieldValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(deliveryTip);
    const deliveryTips = [
        0,
        20,
        30,
        50
    ];
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const handleOnChange = (e)=>{
        if (e.target.value > -1) {
            setFieldValue(e.target.value);
            setDeliveryTip(e.target.value);
        }
    };
    const handleClickOnTips = (tip)=>{
        setFieldValue(tip);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setDeliveryTip(fieldValue);
    }, [
        fieldValue
    ]);
    const handleShow = ()=>{
        setShow(true);
    };
    const handleClose = ()=>{
        setShow(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
            container: true,
            rowGap: "14px",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                    item: true,
                    xs: 12,
                    md: 12,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_7__/* .CouponTitle */ .E9, {
                        children: t("Delivery Man Tips")
                    })
                }),
                !show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                        direction: "row",
                        alignItems: "center",
                        gap: "10px",
                        flexWrap: "wrap",
                        children: [
                            deliveryTips.map((item, index)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomBoxForTips */ .m, {
                                    sx: {
                                        borderColor: (theme)=>fieldValue === item ? theme.palette.primary.main : theme.palette.neutral[200]
                                    },
                                    onClick: ()=>handleClickOnTips(item),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        fontSize: "14px",
                                        children: item
                                    })
                                }, index);
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomBoxForTips */ .m, {
                                sx: {
                                    borderColor: (theme)=>theme.palette.neutral[200]
                                },
                                onClick: handleShow,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    fontSize: "14px",
                                    children: t("Others")
                                })
                            })
                        ]
                    })
                }),
                show && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                    width: "100%",
                    direction: "row",
                    spacing: 1.8,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                            justifyContent: "center",
                            alignItems: "center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                sx: {
                                    backgroundColor: (theme)=>theme.palette.primary.main,
                                    color: (theme)=>theme.palette.neutral[100],
                                    minWidth: "35px",
                                    padding: "8px 10px",
                                    textAlign: "center",
                                    "&:hover": {
                                        backgroundColor: (theme)=>theme.palette.primary.deep
                                    }
                                },
                                onClick: handleClose,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ArrowBackIos__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    sx: {
                                        width: "15px",
                                        height: "20px"
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomTextField */ .yM, {
                                label: t("Amount"),
                                autoFocus: true,
                                value: fieldValue,
                                fullWidth: true,
                                onChange: (e)=>handleOnChange(e)
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryManTip);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 97993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var _PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(77995);
/* harmony import */ var _public_static_digitalpayment_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95230);
/* harmony import */ var _public_static_cash_on_delivery_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45050);
/* harmony import */ var _public_static_wallet_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(99142);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(76829);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__, _PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__]);
([i18next__WEBPACK_IMPORTED_MODULE_5__, _PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const PaymentMethod = ({ paymentMethod , setPaymentMethod , paidBy , orderPlace , isLoading , zoneData , forprescription , configData , storeZoneId , prescriptionPayment  })=>{
    const getCODStatus = ()=>{
        if (configData?.cash_on_delivery) {
            if (zoneData?.data?.zone_data?.length > 0 && storeZoneId) {
                return zoneData?.data?.zone_data?.find((item)=>item?.id === storeZoneId);
            }
        }
    };
    const getDPStatus = ()=>{
        if (configData?.digital_payment) {
            if (zoneData?.data?.zone_data?.length > 0 && storeZoneId) {
                return zoneData?.data?.zone_data?.find((item)=>item?.id === storeZoneId);
            }
        }
    };
    const handleInitialPaymentSelection = ()=>{
        if (getCODStatus()?.cash_on_delivery) {
            setPaymentMethod("cash_on_delivery");
        } else if (getDPStatus()?.digital_payment) {
            setPaymentMethod("digital_payment");
        } else {
            setPaymentMethod("wallet");
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (storeZoneId) {
            handleInitialPaymentSelection();
        }
    }, []);
    const innerDataHandle = ()=>{
        if (prescriptionPayment) {
            if (paymentMethod === "cash_on_delivery") {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomPaperBigCard */ .iD, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                        spacing: 4,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                align: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                    variant: "h6",
                                    children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Payment Method")
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                                spacing: 2,
                                children: [
                                    getCODStatus()?.cash_on_delivery && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Cash on delivery"),
                                        image: _public_static_cash_on_delivery_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                        type: "cash_on_delivery",
                                        description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                        paymentMethod: paymentMethod,
                                        setPaymentMethod: setPaymentMethod,
                                        paidBy: paidBy
                                    }),
                                    getDPStatus()?.digital_payment && paidBy !== "receiver" && forprescription !== "true" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Digital Payment"),
                                        image: _public_static_digitalpayment_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                        type: "digital_payment",
                                        description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                        paymentMethod: paymentMethod,
                                        setPaymentMethod: setPaymentMethod,
                                        paidBy: paidBy
                                    }),
                                    configData?.customer_wallet_status === 1 && paidBy !== "receiver" && forprescription !== "true" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Wallet"),
                                        image: _public_static_wallet_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                        type: "wallet",
                                        description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                        paymentMethod: paymentMethod,
                                        setPaymentMethod: setPaymentMethod,
                                        paidBy: paidBy
                                    })
                                ]
                            }),
                            paidBy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    type: "submit",
                                    fullWidth: true,
                                    variant: "contained",
                                    onClick: orderPlace,
                                    loading: isLoading,
                                    children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Confirm Parcel Request")
                                })
                            })
                        ]
                    })
                });
            }
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomPaperBigCard */ .iD, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 4,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            align: "center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                variant: "h6",
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Payment Method")
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                            spacing: 2,
                            children: [
                                getCODStatus()?.cash_on_delivery && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Cash on delivery"),
                                    image: _public_static_cash_on_delivery_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                    type: "cash_on_delivery",
                                    description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                    paymentMethod: paymentMethod,
                                    setPaymentMethod: setPaymentMethod,
                                    paidBy: paidBy
                                }),
                                getDPStatus()?.digital_payment && paidBy !== "receiver" && forprescription !== "true" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Digital Payment"),
                                    image: _public_static_digitalpayment_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                    type: "digital_payment",
                                    description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                    paymentMethod: paymentMethod,
                                    setPaymentMethod: setPaymentMethod,
                                    paidBy: paidBy
                                }),
                                configData?.customer_wallet_status === 1 && paidBy !== "receiver" && forprescription !== "true" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethodCard__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    paymentType: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Wallet"),
                                    image: _public_static_wallet_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                    type: "wallet",
                                    description: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Faster and safer way to send money"),
                                    paymentMethod: paymentMethod,
                                    setPaymentMethod: setPaymentMethod,
                                    paidBy: paidBy
                                })
                            ]
                        }),
                        paidBy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_10___default()), {
                                type: "submit",
                                fullWidth: true,
                                variant: "contained",
                                onClick: orderPlace,
                                loading: isLoading,
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Confirm Parcel Request")
                            })
                        })
                    ]
                })
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: innerDataHandle()
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(PaymentMethod));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58861);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45269);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(66741);
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__]);
i18next__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const PaymentMethodCard = (props)=>{
    const { image , description , type , paymentMethod , setPaymentMethod , paymentType , paidBy  } = props;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down("md"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
        elevation: 9,
        ...props,
        sx: {
            padding: "20px",
            cursor: "pointer"
        },
        onClick: ()=>setPaymentMethod(type),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            justifyContent: "center",
            alignItems: "center",
            spacing: {
                xs: 1,
                sm: 3,
                md: 4
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xs: 2,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        src: image.src,
                        objectfit: "contain",
                        height: paidBy ? "100%" : isSmall ? "35px" : "40px",
                        width: paidBy ? "100%" : isSmall ? "35px" : "60px"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xs: 8,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            fontWeight: "500",
                            children: (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)(paymentType)
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    xs: 2,
                    textAlign: "right",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw, {
                        children: paymentMethod === type && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_6___default()), {
                            color: "success"
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentMethodCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Prescription_SinglePrescriptionUpload)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/styled-components/CustomStyles.style.js
var CustomStyles_style = __webpack_require__(45269);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: ./src/components/single-file-uploader-with-preview/ImageUploaderWithPreview.js + 2 modules
var ImageUploaderWithPreview = __webpack_require__(57790);
// EXTERNAL MODULE: ./src/components/single-file-uploader-with-preview/ImageAddIcon.js + 1 modules
var ImageAddIcon = __webpack_require__(39626);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(97986);
;// CONCATENATED MODULE: ./src/components/checkout/Prescription/assets/add-image.png
/* harmony default export */ const add_image = ({"src":"/_next/static/media/add-image.06b57ae7.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYElEQVR42l3DMQqCAAAAwEtDaW7sAQ2OfaE1ghqilkAEwQf4BCcX0dHN0Xf4F5+ho3hwHMBRsA6ByN1GrDV7eCr8RPA2Ojv56lwhdDMovWQSuGj0JrVKAoHU30cqF9tbAA/NDNMzGIP4AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/components/checkout/Prescription/SinglePrescriptionUpload.js








const SinglePrescriptionUpload = (props)=>{
    const { t , handleImageUpload  } = props;
    const [image, setImage] = (0,external_react_.useState)(add_image.src);
    (0,external_react_.useEffect)(()=>{
        typeof image !== "string" && handleImageUpload?.(image);
    }, [
        image
    ]);
    const singleFileUploadHandlerForImage = (value)=>{
        setImage(value.currentTarget.files[0]);
    };
    const imageOnchangeHandlerForImage = (value)=>{
        setImage(value);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CustomStyles_style/* CustomStackFullWidth */.Xw, {
        alignItems: "center",
        justifyContent: "center",
        spacing: 3,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                variant: "h6",
                children: [
                    t("Prescription"),
                    " ",
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        style: {
                            color: "red",
                            fontSize: "14px"
                        },
                        children: [
                            "(",
                            t("Max size 2MB"),
                            ")"
                        ]
                    }),
                    " "
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Stack, {
                alignItems: "center",
                justifyContent: "center",
                sx: {
                    position: "relative"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ImageUploaderWithPreview/* default */.Z, {
                        type: "file",
                        labelText: t("file Upload"),
                        hintText: "Image format - jpg, png, jpeg, gif Image Size - maximum size 2 MB Image Ratio - 1:1",
                        file: image,
                        onChange: singleFileUploadHandlerForImage,
                        imageOnChange: imageOnchangeHandlerForImage,
                        width: "10rem",
                        borderRadius: "50%",
                        height: "140px"
                    }),
                    typeof image !== "string" && /*#__PURE__*/ jsx_runtime_.jsx(ImageAddIcon/* default */.Z, {
                        imageChangeHandler: singleFileUploadHandlerForImage
                    })
                ]
            })
        ]
    });
};
SinglePrescriptionUpload.propTypes = {};
/* harmony default export */ const Prescription_SinglePrescriptionUpload = (SinglePrescriptionUpload);


/***/ }),

/***/ 64238:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _item_checkout_DeliveryDetails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1073);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7404);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _PaymentMethod__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(97993);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(91326);
/* harmony import */ var _item_checkout_PlaceOrder__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(61749);
/* harmony import */ var _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67759);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(66366);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(45269);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22021);
/* harmony import */ var _item_checkout_OrderCalculationShimmer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(63848);
/* harmony import */ var _Prescription_PrescriptionOrderCalculation__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(67982);
/* harmony import */ var _Prescription_PrescriptionUpload__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(32631);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(81261);
/* harmony import */ var _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(67019);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(86201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _utils_toasterMessages__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(70557);
/* harmony import */ var _DeliveryManTip__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(26139);
/* harmony import */ var _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(43041);
/* harmony import */ var _item_checkout_demoData__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(9247);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_item_checkout_DeliveryDetails__WEBPACK_IMPORTED_MODULE_3__, _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_5__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_7__, _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_9__, _item_checkout_PlaceOrder__WEBPACK_IMPORTED_MODULE_10__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_11__, i18next__WEBPACK_IMPORTED_MODULE_14__, _Prescription_PrescriptionOrderCalculation__WEBPACK_IMPORTED_MODULE_16__, _Prescription_PrescriptionUpload__WEBPACK_IMPORTED_MODULE_17__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_18__, _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_19__, react_hot_toast__WEBPACK_IMPORTED_MODULE_20__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_22__, _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_23__]);
([_item_checkout_DeliveryDetails__WEBPACK_IMPORTED_MODULE_3__, _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_5__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_7__, _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_9__, _item_checkout_PlaceOrder__WEBPACK_IMPORTED_MODULE_10__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_11__, i18next__WEBPACK_IMPORTED_MODULE_14__, _Prescription_PrescriptionOrderCalculation__WEBPACK_IMPORTED_MODULE_16__, _Prescription_PrescriptionUpload__WEBPACK_IMPORTED_MODULE_17__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_18__, _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_19__, react_hot_toast__WEBPACK_IMPORTED_MODULE_20__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_22__, _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


























const PrescriptionCheckout = ({ storeId  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_21__.useRouter)();
    const matches = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)("(max-width:1180px)");
    const [orderType, setOrderType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("delivery");
    const [address, setAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const [orderSuccess, setOrderSuccess] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [prescriptionImages, setPrescriptionImages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [paymentMethod, setPaymentMethod] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [unavailable_item_note, setUnavailable_item_note] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [delivery_instruction, setDelivery_instruction] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [deliveryTip, setDeliveryTip] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [note, setNote] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.configData);
    const { data: storeData , refetch  } = (0,_api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(storeId);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const currentLatLng = JSON.parse(localStorage.getItem("currentLatLng"));
        const location1 = localStorage.getItem("location");
        setAddress({
            ...currentLatLng,
            latitude: currentLatLng?.lat,
            longitude: currentLatLng?.lng,
            address: location1,
            address_type: "Selected Address"
        });
        refetch();
    }, [
        storeId
    ]);
    const currentLatLng = JSON.parse(window.localStorage.getItem("currentLatLng"));
    const handleChange = (e)=>{
        setNote(e.target.value);
    };
    const { data: zoneData  } = (0,react_query__WEBPACK_IMPORTED_MODULE_8__.useQuery)([
        "zoneId",
        location
    ], async ()=>_api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_9__/* .GoogleApi.getZoneId */ .K.getZoneId(currentLatLng), {
        retry: 1
    });
    const { data: distanceData , refetch: refetchDistance  } = (0,react_query__WEBPACK_IMPORTED_MODULE_8__.useQuery)([
        "get-distance",
        storeData,
        address
    ], ()=>_api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_9__/* .GoogleApi.distanceApi */ .K.distanceApi(storeData, address), {
        enabled: false,
        onError: _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_11__/* .onErrorResponse */ .R
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        storeData && address && refetchDistance();
        handleOrderTypeInitially();
    }, [
        storeData,
        address
    ]);
    const handleOrderTypeInitially = ()=>{
        if (storeData?.delivery && configData?.home_delivery_status === 1 && storeData?.take_away && configData?.takeaway_status === 1) {
            setOrderType("delivery");
        } else if (storeData?.take_away && configData?.takeaway_status === 1) {
            setOrderType("take_away");
        } else if (storeData?.delivery && configData?.home_delivery_status === 1) {
            setOrderType("delivery");
        }
    };
    const { mutate: orderMutation , isLoading: orderLoading  } = (0,react_query__WEBPACK_IMPORTED_MODULE_8__.useMutation)("order-place", _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_19__/* .OrderApi.prescriptionPlaceOrder */ .R.prescriptionPlaceOrder);
    const handleOrderMutationObject = ()=>{
        const originData = {
            latitude: storeData?.latitude,
            longitude: storeData?.longitude
        };
        return {
            ...address,
            // order_time: scheduleAt,
            payment_method: paymentMethod,
            order_type: orderType,
            store_id: storeData?.id,
            distance: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_18__/* .handleDistance */ .NY)(distanceData?.data?.rows?.[0]?.elements, originData, address),
            prescriptionImages: prescriptionImages,
            order_note: note,
            dm_tips: deliveryTip,
            unavailable_item_note,
            delivery_instruction
        };
    };
    const handlePlaceOrder = ()=>{
        const handleSuccessSecond = (res)=>{
            if (res?.data) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_20__.toast.success(res?.data?.message);
                router.push("/order", undefined, {
                    shallow: true
                });
            }
        };
        let order = handleOrderMutationObject();
        orderMutation(order, {
            onSuccess: handleSuccessSecond,
            onError: (error)=>{
                error?.response?.data?.errors?.forEach((item)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_20__.toast.error(item.message, {
                        position: "bottom-right"
                    }));
            }
        });
    };
    const placeOrder = ()=>{
        if (paymentMethod && paymentMethod === "cash_on_delivery") {
            if (prescriptionImages.length > 0) {
                handlePlaceOrder();
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_20__.toast.error(_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_24__/* .prescription_image_error_text */ .gq);
            }
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_20__.toast.error((0,i18next__WEBPACK_IMPORTED_MODULE_14__.t)("Without any payment method, you can not place the order."));
        }
    };
    const handleItemUnavailableNote = (value)=>{
        setUnavailable_item_note(value);
    };
    const handleDeliveryInstructionNote = (value)=>{
        setDelivery_instruction(value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        container: true,
        spacing: 3,
        mb: "2rem",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                md: matches ? 12 : 7,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Prescription_PrescriptionUpload__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                            prescriptionImages: prescriptionImages,
                            setPrescriptionImages: setPrescriptionImages
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_item_checkout_DeliveryDetails__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            storeData: storeData,
                            setOrderType: setOrderType,
                            orderType: orderType,
                            setAddress: setAddress,
                            address: address,
                            configData: configData,
                            forprescription: "true"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__/* .CustomPaperBigCard */ .iD, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryManTip__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                deliveryTip: deliveryTip,
                                setDeliveryTip: setDeliveryTip
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                md: matches ? 12 : 5,
                height: "auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__/* .CustomPaperBigCard */ .iD, {
                        height: "auto",
                        sx: {
                            mb: "1.5rem"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                            title: "Add More Delivery Instruction",
                            data: _item_checkout_demoData__WEBPACK_IMPORTED_MODULE_25__/* .deliveryInstructions */ .q,
                            handleChange: handleDeliveryInstructionNote
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__/* .CustomPaperBigCard */ .iD, {
                        height: "auto",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            spacing: 3,
                            justifyContent: "space-between",
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_12__/* .CouponTitle */ .E9, {
                                    variant: "h6",
                                    children: (0,i18next__WEBPACK_IMPORTED_MODULE_14__.t)("Order Summary")
                                }),
                                distanceData && storeData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Prescription_PrescriptionOrderCalculation__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                    storeData: storeData,
                                    distanceData: distanceData,
                                    configData: configData,
                                    orderType: orderType,
                                    origin: {
                                        latitude: storeData?.latitude,
                                        longitude: storeData?.longitude
                                    },
                                    destination: address,
                                    zoneData: zoneData,
                                    totalOrderAmount: 0,
                                    deliveryTip: deliveryTip
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_item_checkout_OrderCalculationShimmer__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                md: matches ? 12 : 7,
                xs: 12,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__/* .CustomPaperBigCard */ .iD, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            align: "center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                variant: "h6",
                                children: (0,i18next__WEBPACK_IMPORTED_MODULE_14__.t)("Additional Note")
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_13__/* .CustomTextArea */ .Ks, {
                            "aria-label": "empty textarea",
                            placeholder: (0,i18next__WEBPACK_IMPORTED_MODULE_14__.t)("Additional Note"),
                            style: {
                                width: "100%",
                                minHeight: "50px",
                                marginTop: "20px"
                            },
                            onChange: (e)=>handleChange(e)
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                md: matches ? 12 : 7,
                xs: 12,
                children: zoneData && storeData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethod__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    configData: configData,
                    setPaymentMethod: setPaymentMethod,
                    paymentMethod: paymentMethod,
                    zoneData: zoneData,
                    forprescription: "true",
                    storeZoneId: storeData?.zone_id,
                    prescriptionPayment: true
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                md: 12,
                xs: 12,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_item_checkout_PlaceOrder__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    placeOrder: placeOrder,
                    orderLoading: orderLoading,
                    zoneData: zoneData
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PrescriptionCheckout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 33593:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66366);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58861);
/* harmony import */ var _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(89113);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_5__]);
_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const CampaignOrders = ({ configData , campaignItemList , t  })=>{
    const productBaseUrl = configData?.base_urls?.campaign_image_url;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: campaignItemList.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                container: true,
                md: 12,
                xs: 12,
                spacing: {
                    xs: 1
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        md: 4,
                        xs: 4,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            height: "90px",
                            width: "90px",
                            src: `${productBaseUrl}/${item?.image}`,
                            loading: "lazy",
                            borderRadius: "10px"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        md: 8,
                        xs: 8,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .OrderFoodName */ .bv, {
                                children: item?.name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .OrderFoodSubtitle */ .VK, {
                                children: [
                                    t("Qty"),
                                    " : ",
                                    item?.quantity
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .OrderFoodAmount */ .VZ, {
                                children: (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_5__/* .getAmountWithSign */ .B9)(item?.price)
                            })
                        ]
                    })
                ]
            }, item?.id))
    });
};
CampaignOrders.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CampaignOrders);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _CutleryIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42369);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57987);
/* harmony import */ var _header_NavBar_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53523);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
react_i18next__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Cutlery = (props)=>{
    const { isChecked , handleChange  } = props;
    const [checked, setChecked] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(isChecked);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const handleChangeInner = (event)=>{
        setChecked(event.target.checked);
        handleChange?.(event.target.checked);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        direction: "row",
        alignItems: "center",
        justifyContent: "space-between",
        p: "5px",
        spacing: .5,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                spacing: 2,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CutleryIcon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        alignItems: "flex-start",
                        spacing: .5,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                color: "primary",
                                fontWeight: "bold",
                                children: t("Add Cutlery")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                color: "text.secondary",
                                variant: "body2",
                                children: t("Dont have a cutlery? Restaurant will provide you.")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header_NavBar_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomSwitch */ .w8, {
                checked: checked,
                onChange: handleChangeInner,
                noimage: "true"
            })
        ]
    });
};
Cutlery.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cutlery);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 42369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const CutleryIcon = ()=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const primaryColor = theme.palette.primary.main;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "18",
        height: "18",
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M2 18V7.725C1.45 7.725 0.979167 7.52917 0.5875 7.1375C0.195833 6.74583 0 6.275 0 5.725V0.575C0 0.425 0.0583333 0.291667 0.175 0.175C0.291667 0.0583333 0.425 0 0.575 0C0.725 0 0.8625 0.0583333 0.9875 0.175C1.1125 0.291667 1.175 0.425 1.175 0.575V4.125H2.175V0.575C2.175 0.425 2.23333 0.291667 2.35 0.175C2.46667 0.0583333 2.6 0 2.75 0C2.9 0 3.03333 0.0583333 3.15 0.175C3.26667 0.291667 3.325 0.425 3.325 0.575V4.125H4.325V0.575C4.325 0.425 4.3875 0.291667 4.5125 0.175C4.6375 0.0583333 4.775 0 4.925 0C5.075 0 5.20833 0.0583333 5.325 0.175C5.44167 0.291667 5.5 0.425 5.5 0.575V5.725C5.5 6.275 5.30417 6.74583 4.9125 7.1375C4.52083 7.52917 4.05 7.725 3.5 7.725V18H2ZM9 18V7.675C8.31667 7.29167 7.8 6.775 7.45 6.125C7.1 5.475 6.925 4.725 6.925 3.875C6.925 2.875 7.17917 1.97917 7.6875 1.1875C8.19583 0.395833 8.89167 0 9.775 0C10.6583 0 11.3542 0.395833 11.8625 1.1875C12.3708 1.97917 12.625 2.875 12.625 3.875C12.625 4.725 12.4417 5.475 12.075 6.125C11.7083 6.775 11.1833 7.29167 10.5 7.675V18H9ZM14.35 18V0C15.3167 0.0833333 16.1667 0.4625 16.9 1.1375C17.6333 1.8125 18 2.65 18 3.65V9.75H15.85V18H14.35Z",
            fill: primaryColor
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CutleryIcon);


/***/ }),

/***/ 1073:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(88185);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45269);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(66366);
/* harmony import */ var _delivery_address__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66162);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _delivery_address__WEBPACK_IMPORTED_MODULE_10__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _delivery_address__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// import { DeliveryCaption, DeliveryTitle, StyledPaper } from "./CheckOut.style";





// import DeliveryAddress from "./DeliveryAddress";




const DeliveryDetails = (props)=>{
    const { storeData , setOrderType , orderType , setAddress , address , configData , forprescription , setDeliveryTip  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const handleOrderType = (value)=>{
        if (value === "take_away") {
            setDeliveryTip(0);
        }
        setOrderType(value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_8__/* .CustomPaperBigCard */ .iD, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_9__/* .DeliveryTitle */ .UE, {
                children: t("DELIVERY DETAILS")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_9__/* .DeliveryCaption */ .qv, {
                        const: true,
                        id: "demo-row-radio-buttons-group-label",
                        children: t("Delivery Options")
                    }),
                    storeData && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4___default()), {
                        value: orderType,
                        row: true,
                        onChange: (e)=>handleOrderType?.(e.target.value),
                        children: [
                            storeData?.delivery && configData?.home_delivery_status === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default()), {
                                value: "delivery",
                                control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_6___default()), {}),
                                label: t("Home Delivery")
                            }),
                            storeData?.take_away && configData?.takeaway_status === 1 && forprescription !== "true" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default()), {
                                value: "take_away",
                                control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_6___default()), {}),
                                label: t("Take Away")
                            })
                        ]
                    })
                ]
            }),
            orderType === "delivery" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_delivery_address__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                setAddress: setAddress,
                address: address,
                configData: configData,
                storeZoneId: storeData?.zone_id
            })
        ]
    });
};
DeliveryDetails.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 96001:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86201);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _api_manage_another_formated_api_couponApi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(77278);
/* harmony import */ var _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(67759);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(45269);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(66366);
/* harmony import */ var _redux_slices_profileInfo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(65337);
/* harmony import */ var _utils_toasterMessages__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(70557);
/* harmony import */ var _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(89113);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _api_manage_another_formated_api_couponApi__WEBPACK_IMPORTED_MODULE_8__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_9__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_13__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _api_manage_another_formated_api_couponApi__WEBPACK_IMPORTED_MODULE_8__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_9__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// import {
//     CouponButton,
//     CouponGrid,
//     CouponTitle,
//     InputField,
// } from './CheckOut.style'

// import { CouponApi } from '../../hooks/react-query/config/couponApi'

// import { onErrorResponse } from '../ErrorResponse'


// import { setCouponInfo, setCouponType } from '../../redux/slices/configData'
// import {
//     CustomPaperBigCard,
//     CustomStackFullWidth,
// } from '../../styled-components/CustomStyles.style'








const HaveCoupon = ({ store_id , setCouponDiscount , couponDiscount , totalAmount , deliveryFee , deliveryTip  })=>{
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_7__.useTheme)();
    const { couponInfo  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.profileInfo);
    const [couponCode, setCouponCode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(couponInfo?.code);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    let zoneId;
    if (false) {}
    const handleSuccess = (response)=>{
        const totalAmountOverall = totalAmount - deliveryFee - deliveryTip;
        if (Number.parseInt(response?.data?.min_purchase) <= Number.parseInt(totalAmountOverall)) {
            dispatch((0,_redux_slices_profileInfo__WEBPACK_IMPORTED_MODULE_12__/* .setCouponInfo */ .Ey)(response.data));
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success(t("Coupon Applied"));
            dispatch((0,_redux_slices_profileInfo__WEBPACK_IMPORTED_MODULE_12__/* .setCouponType */ .R4)(response.data.coupon_type));
            setCouponDiscount({
                ...response.data,
                zoneId: zoneId
            });
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error(`${t(_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_14__/* .coupon_minimum */ .E0)} ${(0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_13__/* .getAmountWithSign */ .B9)(response?.data?.min_purchase)}`);
        }
    };
    const { isLoading , refetch  } = (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)("apply-coupon", ()=>_api_manage_another_formated_api_couponApi__WEBPACK_IMPORTED_MODULE_8__/* .CouponApi.applyCoupon */ .X.applyCoupon(couponCode, store_id), {
        onSuccess: handleSuccess,
        onError: _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_9__/* .onErrorResponse */ .R,
        enabled: false,
        retry: 1
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        return ()=>{
            dispatch((0,_redux_slices_profileInfo__WEBPACK_IMPORTED_MODULE_12__/* .setCouponInfo */ .Ey)(null));
        };
    }, []);
    const removeCoupon = ()=>{
        // setCouponDiscount(null);
        localStorage.removeItem("coupon");
        setCouponCode(null);
        dispatch((0,_redux_slices_profileInfo__WEBPACK_IMPORTED_MODULE_12__/* .setCouponInfo */ .Ey)(null));
    };
    const handleApply = async ()=>{
        await refetch();
    };
    const borderColor = theme.palette.primary.main;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__/* .CustomPaperBigCard */ .iD, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
            container: true,
            spacing: {
                xs: 1,
                md: 1
            },
            justifyContent: "flex-start",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 12,
                    xs: 12,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_11__/* .CouponTitle */ .E9, {
                        children: t("Have a Coupon?")
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 6,
                    xs: 12,
                    sm: 7,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_11__/* .InputField */ .UP, {
                        variant: "outlined",
                        sx: {
                            height: "100%",
                            border: `.5px solid ${borderColor}`
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputBase, {
                            placeholder: t("Enter Your Coupon.."),
                            sx: {
                                ml: 1,
                                flex: 1,
                                width: "100%",
                                padding: "5px 10px 5px",
                                [theme.breakpoints.down("sm")]: {
                                    fontSize: "12px"
                                }
                            },
                            onChange: (e)=>setCouponCode(e.target.value),
                            value: couponCode ? couponCode : "",
                            onKeyPress: (e)=>{
                                if (e.key === "Enter") {
                                    handleApply();
                                }
                            }
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 3,
                    xs: 12,
                    sm: 5,
                    children: [
                        !couponInfo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_11__/* .CouponButton */ .ol, {
                            loading: isLoading,
                            loadingPosition: "start",
                            variant: "contained",
                            onClick: handleApply,
                            disabled: couponCode === "" || !couponCode,
                            children: t("Apply Now")
                        }),
                        couponInfo && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_11__/* .CouponButton */ .ol, {
                            // loading={isLoading}
                            loadingPosition: "start",
                            variant: "contained",
                            onClick: removeCoupon,
                            children: t("Remove")
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HaveCoupon);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77364:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66366);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _CustomDivider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35740);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(81261);
/* harmony import */ var _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(89113);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(23614);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__, _helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const OrderCalculation = (props)=>{
    const { cartList , storeData , couponDiscount , taxAmount , distanceData , total_order_amount , configData , orderType , couponInfo , deliveryTip , origin , destination , zoneData , setDeliveryFee , extraCharge , extraChargeLoading  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const [freeDelivery, setFreeDelivery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("false");
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.useTheme)();
    let couponType = "coupon";
    const handleDeliveryFee = ()=>{
        let price = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getDeliveryFees */ .WT)(storeData, configData, cartList, distanceData?.data, couponDiscount, couponType, orderType, zoneData, origin, destination, extraCharge);
        setDeliveryFee(orderType === "delivery" ? 0 : price);
        if (price === 0) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                fontWeight: "bold",
                children: t("Free")
            });
        } else {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                direction: "row",
                alignItems: "center",
                justifyContent: "flex-end",
                spacing: 0.5,
                width: "100%",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        fontWeight: "bold",
                        children: "(+)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        fontWeight: "bold",
                        children: storeData && (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)(price)
                    })
                ]
            });
        }
    };
    const handleCouponDiscount = ()=>{
        let couponDiscountValue = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getCouponDiscount */ .x7)(couponDiscount, storeData, cartList);
        if (couponDiscount && couponDiscount.coupon_type === "free_delivery") {
            setFreeDelivery("true");
            return 0;
        } else {
            return (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)(couponDiscountValue);
        }
    };
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const handleOrderAmount = ()=>{
        let totalAmount = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getCalculatedTotal */ .r7)(cartList, couponDiscount, storeData, configData, distanceData, couponType, orderType, freeDelivery, Number(deliveryTip), zoneData, origin, destination, extraCharge);
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__/* .setTotalAmount */ .O$)(totalAmount));
        return (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)(totalAmount);
    };
    const discountedPrice = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getProductDiscount */ .BH)(cartList, storeData);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .CalculationGrid */ .M0, {
            container: true,
            item: true,
            md: 12,
            xs: 12,
            spacing: 1,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 8,
                    xs: 8,
                    children: cartList.length > 1 ? t("Items Price") : t("Item Price")
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 4,
                    xs: 4,
                    align: "right",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        fontWeight: "bold",
                        align: "right",
                        children: (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)((0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getSubTotalPrice */ .P)(cartList))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 8,
                    xs: 8,
                    children: t("Discount")
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    item: true,
                    md: 4,
                    xs: 4,
                    align: "right",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        width: "100%",
                        direction: "row",
                        alignItems: "center",
                        justifyContent: "flex-end",
                        spacing: 0.5,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "bold",
                                children: "(-)"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "bold",
                                children: storeData ? (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)(discountedPrice) : null
                            })
                        ]
                    })
                }),
                couponDiscount ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 8,
                            xs: 8,
                            children: t("Coupon Discount")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 4,
                            xs: 4,
                            align: "right",
                            children: couponDiscount.coupon_type === "free_delivery" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "bold",
                                children: t("Free Delivery")
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "flex-end",
                                spacing: 0.5,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: "(-)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: storeData && cartList && handleCouponDiscount()
                                    })
                                ]
                            })
                        })
                    ]
                }) : null,
                storeData ? storeData?.tax ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 8,
                            xs: 8,
                            children: [
                                t("TAX"),
                                " (",
                                storeData?.tax,
                                "%",
                                " ",
                                configData?.tax_included === 1 && t("Included"),
                                ")"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 4,
                            xs: 4,
                            align: "right",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "flex-end",
                                spacing: 0.5,
                                children: [
                                    configData?.tax_included === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: "(+)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: storeData && (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)((0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_8__/* .getTaxableTotalPrice */ .be)(cartList, couponDiscount, storeData))
                                    })
                                ]
                            })
                        })
                    ]
                }) : null : null,
                orderType === "delivery" ? Number.parseInt(configData?.dm_tips_status) === 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 8,
                            xs: 8,
                            children: t("Deliveryman tips")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 4,
                            xs: 4,
                            align: "right",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "flex-end",
                                spacing: 0.5,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: "(+)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontWeight: "bold",
                                        children: (0,_helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_9__/* .getAmountWithSign */ .B9)(deliveryTip)
                                    })
                                ]
                            })
                        })
                    ]
                }) : null : null,
                orderType === "delivery" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 8,
                            xs: 8,
                            children: t("Delivery fee")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 4,
                            xs: 4,
                            align: "right",
                            children: couponDiscount ? couponDiscount?.coupon_type === "free_delivery" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "bold",
                                children: t("Free")
                            }) : storeData && handleDeliveryFee() : storeData && handleDeliveryFee()
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomDivider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_CheckOut_style__WEBPACK_IMPORTED_MODULE_3__/* .TotalGrid */ .v5, {
                    container: true,
                    md: 12,
                    xs: 12,
                    mt: "1rem",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 8,
                            xs: 8,
                            pl: ".5rem",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                fontWeight: "bold",
                                color: theme.palette.primary.main,
                                children: t("Total")
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            md: 4,
                            xs: 4,
                            align: "right",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                color: theme.palette.primary.main,
                                align: "right",
                                children: storeData && cartList && handleOrderAmount()
                            })
                        })
                    ]
                })
            ]
        })
    });
};
OrderCalculation.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderCalculation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);




const OrderCalculationShimmer = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        spacing: 1,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                        variant: "text",
                        width: "50px"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderCalculationShimmer);


/***/ }),

/***/ 88666:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66366);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var _RegularOrders__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(30072);
/* harmony import */ var _CampaignOrders__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33593);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(94172);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29233);
/* harmony import */ var simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _RegularOrders__WEBPACK_IMPORTED_MODULE_6__, _CampaignOrders__WEBPACK_IMPORTED_MODULE_7__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _RegularOrders__WEBPACK_IMPORTED_MODULE_6__, _CampaignOrders__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const OrderSummaryDetails = (props)=>{
    const { page , configData , cartList , t , campaignItemListz  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
            item: true,
            md: 12,
            xs: 12,
            container: true,
            spacing: 1,
            mt: "10px",
            pl: "10px",
            children: [
                (page === "cart" || page === "buy_now") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RegularOrders__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    configData: configData,
                    cartList: cartList,
                    t: t
                }),
                page === "campaign" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CampaignOrders__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    configData: configData,
                    campaignItemList: campaignItemList,
                    t: t
                })
            ]
        })
    });
};
OrderSummaryDetails.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderSummaryDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 61749:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(66366);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76829);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(77591);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
react_i18next__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







// import { CustomTypographyGray } from '../../error/Errors.style'
// import { CustomTypography } from '../../custom-tables/Tables.style'



const PlaceOrder = (props)=>{
    const { placeOrder , orderLoading , zoneData , orderType  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const [checked, setChecked] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleChange = (e)=>{
        setChecked(e.target.checked);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomPaperBigCard */ .iD, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
            alignItems: "center",
            spacing: 2,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormGroup, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.FormControlLabel, {
                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Checkbox, {
                            checked: checked,
                            onChange: handleChange
                        }),
                        label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_8__/* .CustomTypography */ .ZT, {
                            children: [
                                t(`I agree that placing the order places me under`),
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    href: "/terms-and-conditions",
                                    style: {
                                        textDecoration: "underline"
                                    },
                                    children: t("Terms and Conditions")
                                }),
                                " ",
                                t("&"),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    href: "/privacy-policy",
                                    style: {
                                        textDecoration: "underline"
                                    },
                                    children: [
                                        " ",
                                        t("Privacy Policy")
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_7___default()), {
                    type: "submit",
                    fullWidth: true,
                    variant: "contained",
                    onClick: placeOrder,
                    loading: orderLoading,
                    disabled: !checked,
                    children: t("Place Order")
                })
            ]
        })
    });
};
PlaceOrder.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlaceOrder);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 91793:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(81261);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(66366);
/* harmony import */ var _alert_CustomAlert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67294);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__, _alert_CustomAlert__WEBPACK_IMPORTED_MODULE_8__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__, _alert_CustomAlert__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const RestaurantScheduleTime = (props)=>{
    const { storeData , handleChange , today , tomorrow , numberOfDay , configData , setScheduleAt  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const slotDurationTime = configData?.schedule_order_slot_duration === 0 ? 30 : configData?.schedule_order_slot_duration;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: storeData?.schedule_order && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomPaperBigCard */ .iD, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                container: true,
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        xs: 12,
                        md: 12,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomTypographyBold */ .n2, {
                            children: t("Preferable Time")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_3___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputLabel, {
                                    children: t("Time")
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Select, {
                                    label: t("Time"),
                                    onChange: handleChange,
                                    defaultValue: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getDayNumber */ .Tw)(today),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                            value: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getDayNumber */ .Tw)(today),
                                            sx: {
                                                "&:hover": {
                                                    backgroundColor: "primary.main"
                                                }
                                            },
                                            children: t("Today")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                            value: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getDayNumber */ .Tw)(tomorrow),
                                            sx: {
                                                "&:hover": {
                                                    backgroundColor: "primary.main"
                                                }
                                            },
                                            children: t("Tomorrow")
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getAllSchedule */ .hU)(numberOfDay, storeData?.schedules, slotDurationTime).length !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        md: 6,
                        xs: 12,
                        children: storeData?.schedules && storeData?.schedules?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_7__/* .PreferableTimeInput */ .cE, {
                            defaultValue: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getDayNumber */ .Tw)(today) === numberOfDay ? t("Now") : "",
                            disablePortal: true,
                            id: "combo-box-demo",
                            options: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getAllSchedule */ .hU)(numberOfDay, storeData?.schedules, slotDurationTime),
                            onChange: (e, option)=>setScheduleAt(option?.value),
                            renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                                    ...params,
                                    label: t("Schedule")
                                })
                        }, numberOfDay)
                    }),
                    (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_6__/* .getAllSchedule */ .hU)(numberOfDay, storeData?.schedules, slotDurationTime).length === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        item: true,
                        xs: 12,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_alert_CustomAlert__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            type: "info",
                            text: "Store closed."
                        })
                    })
                ]
            })
        })
    });
};
RestaurantScheduleTime.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RestaurantScheduleTime);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ productUnavailableData),
/* harmony export */   "q": () => (/* binding */ deliveryInstructions)
/* harmony export */ });
const productUnavailableData = [
    "Remove it form my cart",
    "I will wait until it is restocked",
    "Please cancel the order",
    "Call me ASAP",
    "Notify me when it is back"
];
const deliveryInstructions = [
    "Deliver to the front door",
    "Deliver to the reception desk",
    "Avoid calling phone",
    "Come with no sound"
];


/***/ }),

/***/ 97215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45269);
/* harmony import */ var _DeliveryDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1073);
/* harmony import */ var _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7404);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57987);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(81261);
/* harmony import */ var _utils_formatedDays__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(12212);
/* harmony import */ var _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(91326);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(67759);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(86201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(67019);
/* harmony import */ var _api_manage_another_formated_api_profileApi__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(84379);
/* harmony import */ var _RestaurantScheduleTime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(91793);
/* harmony import */ var _HaveCoupon__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(96001);
/* harmony import */ var _DeliveryManTip__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(26139);
/* harmony import */ var _CheckOut_style__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(66366);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(94172);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(48710);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _OrderSummaryDetails__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(88666);
/* harmony import */ var _OrderCalculationShimmer__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(63848);
/* harmony import */ var _OrderCalculation__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(77364);
/* harmony import */ var _PaymentMethod__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(97993);
/* harmony import */ var _PlaceOrder__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(61749);
/* harmony import */ var _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(61176);
/* harmony import */ var _utils_toasterMessages__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(70557);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(23614);
/* harmony import */ var _helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(90603);
/* harmony import */ var _Prescription_SinglePrescriptionUpload__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(8454);
/* harmony import */ var _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(8142);
/* harmony import */ var _helper_functions_getStoresOrRestaurants__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(37698);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(13332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _Cutlery__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(66070);
/* harmony import */ var _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(43041);
/* harmony import */ var _demoData__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(9247);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_DeliveryDetails__WEBPACK_IMPORTED_MODULE_5__, _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_11__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_13__, react_hot_toast__WEBPACK_IMPORTED_MODULE_14__, _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_16__, _api_manage_another_formated_api_profileApi__WEBPACK_IMPORTED_MODULE_17__, _RestaurantScheduleTime__WEBPACK_IMPORTED_MODULE_18__, _HaveCoupon__WEBPACK_IMPORTED_MODULE_19__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_20__, _OrderSummaryDetails__WEBPACK_IMPORTED_MODULE_24__, _OrderCalculation__WEBPACK_IMPORTED_MODULE_26__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_27__, _PlaceOrder__WEBPACK_IMPORTED_MODULE_28__, _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_29__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_32__, _helper_functions_getStoresOrRestaurants__WEBPACK_IMPORTED_MODULE_33__, _Cutlery__WEBPACK_IMPORTED_MODULE_35__, _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_36__]);
([_DeliveryDetails__WEBPACK_IMPORTED_MODULE_5__, _api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_11__, _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_13__, react_hot_toast__WEBPACK_IMPORTED_MODULE_14__, _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_16__, _api_manage_another_formated_api_profileApi__WEBPACK_IMPORTED_MODULE_17__, _RestaurantScheduleTime__WEBPACK_IMPORTED_MODULE_18__, _HaveCoupon__WEBPACK_IMPORTED_MODULE_19__, _DeliveryManTip__WEBPACK_IMPORTED_MODULE_20__, _OrderSummaryDetails__WEBPACK_IMPORTED_MODULE_24__, _OrderCalculation__WEBPACK_IMPORTED_MODULE_26__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_27__, _PlaceOrder__WEBPACK_IMPORTED_MODULE_28__, _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_29__, _redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_32__, _helper_functions_getStoresOrRestaurants__WEBPACK_IMPORTED_MODULE_33__, _Cutlery__WEBPACK_IMPORTED_MODULE_35__, _ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_36__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








































const ItemCheckout = (props)=>{
    const { configData , router , page , cartList , campaignItemList , totalAmount  } = props;
    const [orderType, setOrderType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [address, setAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const { couponInfo  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.profileInfo);
    const [paymentMethod, setPaymentMethod] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("cash_on_delivery");
    const [numberOfDay, setDayNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)((0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getDayNumber */ .Tw)(_utils_formatedDays__WEBPACK_IMPORTED_MODULE_10__/* .today */ .Lg));
    const [couponDiscount, setCouponDiscount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [scheduleAt, setScheduleAt] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("now");
    const [orderSuccess, setOrderSuccess] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [taxAmount, setTaxAmount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [cutlery, setCutlery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [unavailable_item_note, setUnavailable_item_note] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [delivery_instruction, setDelivery_instruction] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [total_order_amount, setTotalOrderAmount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [enabled, setEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(cartList?.length ? true : false);
    const [deliveryTip, setDeliveryTip] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [deliveryFee, setDeliveryFee] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [isImageSelected, setIsImageSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const currentModuleType = (0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_37__/* .getCurrentModuleType */ .X)();
    const storeId = page === "campaign" ? campaignItemList?.[0]?.store_id : cartList?.[0]?.store_id;
    const { data: storeData , refetch  } = (0,_api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(storeId);
    const handleAddress = ()=>{
        const currentLatLng = JSON.parse(localStorage.getItem("currentLatLng"));
        const location1 = localStorage.getItem("location");
        setAddress({
            ...currentLatLng,
            latitude: currentLatLng?.lat,
            longitude: currentLatLng?.lng,
            address: location1,
            address_type: "Selected Address"
        });
    };
    const currentLatLng = JSON.parse(window.localStorage.getItem("currentLatLng"));
    const { data: zoneData  } = (0,react_query__WEBPACK_IMPORTED_MODULE_12__.useQuery)([
        "zoneId",
        location
    ], async ()=>_api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_11__/* .GoogleApi.getZoneId */ .K.getZoneId(currentLatLng), {
        retry: 1
    });
    const { data: distanceData , refetch: refetchDistance  } = (0,react_query__WEBPACK_IMPORTED_MODULE_12__.useQuery)([
        "get-distance",
        storeData,
        address
    ], ()=>_api_manage_hooks_react_query_googleApi__WEBPACK_IMPORTED_MODULE_11__/* .GoogleApi.distanceApi */ .K.distanceApi(storeData, address), {
        enabled: false,
        onError: _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_13__/* .onErrorResponse */ .R
    });
    const tempDistance = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .handleDistance */ .NY)(distanceData?.data?.rows?.[0]?.elements, {
        latitude: storeData?.latitude,
        longitude: storeData?.longitude
    }, address);
    const { data: extraCharge , isLoading: extraChargeLoading , refetch: extraChargeRefetch  } = (0,_api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z)({
        tempDistance
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (distanceData) {
            extraChargeRefetch();
        }
    }, [
        distanceData
    ]);
    const handleChange = (event)=>{
        setDayNumber(event.target.value);
    };
    //order post api
    const { mutate: orderMutation , isLoading: orderLoading  } = (0,react_query__WEBPACK_IMPORTED_MODULE_12__.useMutation)("order-place", _api_manage_another_formated_api_orderApi__WEBPACK_IMPORTED_MODULE_16__/* .OrderApi.placeOrder */ .R.placeOrder);
    const userOnSuccessHandler = (res)=>{
    // dispatch(setUser(res.data))
    // dispatch(setWalletAmount(res?.data?.wallet_balance))
    };
    const { isLoading: customerLoading , data: customerData  } = (0,react_query__WEBPACK_IMPORTED_MODULE_12__.useQuery)([
        "profile-info"
    ], _api_manage_another_formated_api_profileApi__WEBPACK_IMPORTED_MODULE_17__/* .ProfileApi.profileInfo */ .R.profileInfo, {
        onSuccess: userOnSuccessHandler,
        onError: _api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_13__/* .onSingleErrorResponse */ .f
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleAddress();
        refetch();
    }, [
        storeId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        storeData && address && refetchDistance();
        handleOrderTypeInitially();
    }, [
        storeData,
        address
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const taxAmount = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getTaxableTotalPrice */ .be)(cartList, couponDiscount, storeData?.tax, storeData);
        setTaxAmount(taxAmount);
    }, [
        cartList,
        couponDiscount,
        storeData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const total_order_amount = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getFinalTotalPrice */ .vZ)(cartList, couponDiscount, taxAmount, storeData);
        setTotalOrderAmount(total_order_amount);
    }, [
        cartList,
        couponDiscount,
        taxAmount
    ]);
    const handleOrderTypeInitially = ()=>{
        if (storeData?.delivery && configData?.home_delivery_status === 1 && storeData?.take_away && configData?.takeaway_status === 1) {
            setOrderType("delivery");
        } else if (storeData?.take_away && configData?.takeaway_status === 1) {
            setOrderType("take_away");
        } else if (storeData?.delivery && configData?.home_delivery_status === 1) {
            setOrderType("delivery");
        }
    };
    const handleValuesFromCartItems = (variationValues)=>{
        let value = [];
        if (variationValues?.length > 0) {
            variationValues?.forEach((item)=>{
                if (item?.isSelected) {
                    value.push(item.label);
                }
            });
        } else {
            value.push(variationValues[0].label);
        }
        return value;
    };
    const handleProductList = (productList, totalQty)=>{
        return productList?.map((cart)=>{
            return {
                add_on_ids: cart?.selectedAddons?.length > 0 ? cart?.selectedAddons?.map((add)=>{
                    return add.id;
                }) : [],
                add_on_qtys: cart?.selectedAddons?.length > 0 ? cart?.selectedAddons?.map((add)=>{
                    totalQty += add.quantity;
                    return totalQty;
                }) : [],
                add_ons: cart?.selectedAddons?.length > 0 ? cart?.selectedAddons?.map((add)=>{
                    return {
                        id: add.id,
                        name: add.name,
                        price: add.price
                    };
                }) : [],
                item_id: cart?.available_date_starts ? null : cart?.id,
                item_campaign_id: cart?.available_date_starts ? cart?.id : null,
                price: cart?.price,
                quantity: cart?.quantity,
                variant: cart?.module_type === "food" ? (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getVariation */ .KF)(cart?.variation) : [],
                //new variation form needs to added here
                variation: cart?.module_type === "food" ? cart?.food_variations?.length > 0 ? cart?.food_variations?.map((variation)=>{
                    return {
                        name: variation.name,
                        values: {
                            label: handleValuesFromCartItems(variation.values)
                        }
                    };
                }) : [] : cart?.selectedOption?.length > 0 ? cart?.selectedOption : []
            };
        });
    };
    const handleOrderMutationObject = (carts, productList)=>{
        const originData = {
            latitude: storeData?.latitude,
            longitude: storeData?.longitude
        };
        if ((0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_37__/* .getCurrentModuleType */ .X)() === "pharmacy") {
            const formData = new FormData();
            formData.append("cart", JSON.stringify(carts));
            if (scheduleAt !== "now") {
                formData.append("schedule_at", scheduleAt);
            }
            formData.append("payment_method", paymentMethod);
            formData.append("order_type", orderType);
            formData.append("store_id", storeData?.id);
            if (couponDiscount?.code) {
                formData.append("coupon_code", couponDiscount?.code);
            }
            formData.append("coupon_discount_amount", couponDiscount?.discount);
            formData.append("coupon_discount_title", couponDiscount?.title);
            formData.append("discount_amount", (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getProductDiscount */ .BH)(productList));
            formData.append("distance", (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .handleDistance */ .NY)(distanceData?.data?.rows?.[0]?.elements, originData, address));
            formData.append("order_amount", totalAmount);
            formData.append("dm_tips", deliveryTip);
            formData.append("address", address?.address);
            formData.append("address_type", address?.address_type);
            formData.append("lat", address?.lat);
            formData.append("latitude", address?.latitude);
            formData.append("lng", address?.lng);
            formData.append("longitude", address?.longitude);
            if (isImageSelected?.length > 0) {
                isImageSelected?.forEach((item)=>formData.append("order_attachment", item));
            }
            return formData;
        } else {
            return {
                cart: JSON.stringify(carts),
                ...address,
                schedule_at: scheduleAt === "now" ? null : scheduleAt,
                // order_time: scheduleAt,
                payment_method: paymentMethod,
                order_type: orderType,
                store_id: storeData?.id,
                coupon_code: couponDiscount?.code,
                coupon_discount_amount: couponDiscount?.discount,
                coupon_discount_title: couponDiscount?.title,
                discount_amount: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getProductDiscount */ .BH)(productList),
                distance: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .handleDistance */ .NY)(distanceData?.data?.rows?.[0]?.elements, originData, address),
                order_amount: 100,
                dm_tips: deliveryTip,
                cutlery: cutlery,
                unavailable_item_note,
                delivery_instruction
            };
        }
    };
    const handlePlaceOrder = ()=>{
        const itemsList = page === "campaign" ? campaignItemList : cartList;
        const isAvailable = storeData?.schedule_order ? (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .isFoodAvailableBySchedule */ .Yu)(itemsList, scheduleAt) : true;
        if (isAvailable) {
            const walletAmount = customerData?.data?.wallet_balance;
            let productList = page === "campaign" ? campaignItemList : cartList;
            if (paymentMethod === "wallet") {
                if (Number(walletAmount) < Number(totalAmount)) {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(t("Wallet balance is below total amount."), {
                        id: "wallet",
                        position: "bottom-right"
                    });
                } else {
                    let totalQty = 0;
                    let carts = handleProductList(productList, totalQty);
                    const handleSuccessSecond = (response)=>{
                        if (response?.data) {
                            if (paymentMethod === "digital_payment") {
                                react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.success(response?.data?.message);
                                const newBaseUrl = _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_29__/* .baseUrl */ .F;
                                const callBackUrl = `${window.location.origin}/order?order_id=${response?.data?.order_id}&total=${response?.data?.total_ammount}`;
                                const url = `${newBaseUrl}/payment-mobile?order_id=${response?.data?.order_id}&customer_id=${customerData?.data?.id}&callback=${callBackUrl}`;
                                localStorage.setItem("totalAmount", totalAmount);
                                dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__/* .setClearCart */ .aE)());
                                next_router__WEBPACK_IMPORTED_MODULE_15___default().push(url, undefined, {
                                    shallow: true
                                });
                            } else if (paymentMethod === "wallet") {
                                react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.success(response?.data?.message);
                                setOrderSuccess(true);
                            } else {
                                if (response.status === 203) {
                                    react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(response.data.errors[0].message);
                                }
                            //setOrderSuccess(true)
                            }
                        }
                    };
                    if (carts?.length > 0) {
                        let order = handleOrderMutationObject(carts, productList);
                        orderMutation(order, {
                            onSuccess: handleSuccessSecond,
                            onError: (error)=>{
                                error?.response?.data?.errors?.forEach((item)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(item.message, {
                                        position: "bottom-right"
                                    }));
                            }
                        });
                    }
                }
            } else {
                let totalQty1 = 0;
                let carts1 = handleProductList(productList, totalQty1);
                const handleSuccess = (response)=>{
                    if (response?.data) {
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.success(response?.data?.message, {
                            id: paymentMethod
                        });
                        if (paymentMethod === "digital_payment") {
                            const callBackUrl = `${window.location.origin}/order?order_id=${response?.data?.order_id}&total=${response?.data?.total_ammount}`;
                            const url = `${_api_manage_MainApi__WEBPACK_IMPORTED_MODULE_29__/* .baseUrl */ .F}/payment-mobile?order_id=${response?.data?.order_id}&customer_id=${customerData?.data?.id}&callback=${callBackUrl}`;
                            localStorage.setItem("totalAmount", totalAmount);
                            dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__/* .setClearCart */ .aE)());
                            next_router__WEBPACK_IMPORTED_MODULE_15___default().push(url, undefined, {
                                shallow: true
                            });
                        } else {
                            setOrderSuccess(true);
                        }
                    }
                };
                if (carts1?.length > 0) {
                    let order1 = handleOrderMutationObject(carts1, productList);
                    orderMutation(order1, {
                        onSuccess: handleSuccess,
                        onError: (error)=>{
                            error?.response?.data?.errors?.forEach((item)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(item.message, {
                                    position: "bottom-right"
                                }));
                        }
                    });
                }
            }
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(t("One or more item is not available for the chosen preferable schedule time."));
        }
    };
    const isStoreOpen = ()=>{
    // storeData?.schedule_order
    };
    const storeCloseToast = ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(t(`${(0,_helper_functions_getStoresOrRestaurants__WEBPACK_IMPORTED_MODULE_33__/* .getStoresOrRestaurants */ .s)().slice(0, -1)} is closed. Try again later.`));
    const handlePlaceOrderBasedOnAvailability = ()=>{
        //cod -> cash on delivery
        const codLimit = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .getInfoFromZoneData */ .PR)(zoneData)?.pivot?.maximum_cod_order_amount;
        if (orderType === "take_away") {
            handlePlaceOrder();
        } else {
            if (paymentMethod === "cash_on_delivery" && codLimit) {
                if (totalAmount <= codLimit) {
                    handlePlaceOrder();
                } else {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_14__.toast.error(t(_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_38__/* .cod_exceeds_message */ ._b), {
                        duration: 5000
                    });
                }
            } else {
                handlePlaceOrder();
            }
        }
    };
    const placeOrder = ()=>{
        if (storeData?.active) {
            //checking restaurant or shop open or not
            if (storeData?.schedules.length > 0) {
                const todayInNumber = moment_moment__WEBPACK_IMPORTED_MODULE_34___default()().weekday();
                let isOpen = false;
                let filteredSchedules = storeData?.schedules.filter((item)=>item.day === todayInNumber);
                let isAvailableNow = [];
                filteredSchedules.forEach((item)=>{
                    if ((0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_9__/* .isAvailable */ ._e)(item?.opening_time, item?.closing_time)) {
                        isAvailableNow.push(item);
                    }
                });
                if (isAvailableNow.length > 0) {
                    isOpen = true;
                } else {
                    isOpen = false;
                }
                if (isOpen) {
                    handlePlaceOrderBasedOnAvailability();
                }
            } else {
                storeCloseToast();
            }
        } else {
            storeCloseToast();
        }
    };
    const couponRemove = ()=>{};
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        orderSuccess && handleOrderSuccess();
    }, [
        orderSuccess
    ]);
    const handleOrderSuccess = ()=>{
        if (page === "buy_now") {
            dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_30__/* .setRemoveItemFromCart */ .jh)(cartList?.[0]));
        }
        localStorage.setItem("totalAmount", totalAmount);
        next_router__WEBPACK_IMPORTED_MODULE_15___default().push("/order", undefined, {
            shallow: true
        });
    };
    const handleImageUpload = (value)=>{
        setIsImageSelected([
            value
        ]);
    };
    const paymentMethodShow = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethod__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
            setPaymentMethod: setPaymentMethod,
            paymentMethod: paymentMethod,
            zoneData: zoneData,
            configData: configData,
            storeZoneId: storeData?.zone_id
        });
    const handleCutlery = (status)=>{
        if (status) {
            setCutlery(1);
        } else {
            setCutlery(1);
        }
    };
    const handleItemUnavailableNote = (value)=>{
        setUnavailable_item_note(value);
    };
    const handleDeliveryInstructionNote = (value)=>{
        setDelivery_instruction(value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        container: true,
        spacing: 3,
        mb: "2rem",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                md: 7,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryDetails__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            storeData: storeData,
                            setOrderType: setOrderType,
                            orderType: orderType,
                            setAddress: setAddress,
                            address: address,
                            configData: configData,
                            setDeliveryTip: setDeliveryTip
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RestaurantScheduleTime__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                            storeData: storeData,
                            handleChange: handleChange,
                            today: _utils_formatedDays__WEBPACK_IMPORTED_MODULE_10__/* .today */ .Lg,
                            tomorrow: _utils_formatedDays__WEBPACK_IMPORTED_MODULE_10__/* .tomorrow */ .Ro,
                            numberOfDay: numberOfDay,
                            configData: configData,
                            setScheduleAt: setScheduleAt
                        }),
                        storeData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HaveCoupon__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                            store_id: storeData?.id,
                            setCouponDiscount: setCouponDiscount,
                            counponRemove: couponRemove,
                            couponDiscount: couponDiscount,
                            totalAmount: totalAmount,
                            deliveryFee: deliveryFee,
                            deliveryTip: deliveryTip
                        }),
                        orderType === "delivery" ? Number.parseInt(configData?.dm_tips_status) === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomPaperBigCard */ .iD, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryManTip__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                deliveryTip: deliveryTip,
                                setDeliveryTip: setDeliveryTip
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: zoneData && storeData && paymentMethodShow()
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                xs: 12,
                md: 5,
                height: "auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomPaperBigCard */ .iD, {
                            height: "auto",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                spacing: 3,
                                justifyContent: "space-between",
                                alignItems: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckOut_style__WEBPACK_IMPORTED_MODULE_21__/* .CouponTitle */ .E9, {
                                        variant: "h6",
                                        children: t("Order Summary")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((simplebar_react__WEBPACK_IMPORTED_MODULE_22___default()), {
                                        style: {
                                            maxHeight: "500px",
                                            width: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_OrderSummaryDetails__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                            page: page,
                                            configData: configData,
                                            cartList: cartList,
                                            t: t,
                                            campaignItemList: campaignItemList
                                        })
                                    }),
                                    (0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_37__/* .getCurrentModuleType */ .X)() === "food" && storeData?.cutlery && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cutlery__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .Z, {
                                        isChecked: cutlery,
                                        handleChange: handleCutlery
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z, {
                                        title: "If Any product is not available",
                                        data: _demoData__WEBPACK_IMPORTED_MODULE_39__/* .productUnavailableData */ .F,
                                        handleChange: handleItemUnavailableNote
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ItemSelectWithChip__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z, {
                                        title: "Add More Delivery Instruction",
                                        data: _demoData__WEBPACK_IMPORTED_MODULE_39__/* .deliveryInstructions */ .q,
                                        handleChange: handleDeliveryInstructionNote
                                    }),
                                    distanceData && storeData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_OrderCalculation__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                        cartList: page === "campaign" ? campaignItemList : cartList,
                                        storeData: storeData,
                                        couponDiscount: couponDiscount,
                                        taxAmount: taxAmount,
                                        distanceData: distanceData,
                                        total_order_amount: total_order_amount,
                                        configData: configData,
                                        couponInfo: couponInfo,
                                        orderType: orderType,
                                        deliveryTip: deliveryTip,
                                        origin: {
                                            latitude: storeData?.latitude,
                                            longitude: storeData?.longitude
                                        },
                                        destination: address,
                                        zoneData: zoneData,
                                        extraCharge: extraCharge && extraCharge,
                                        setDeliveryFee: setDeliveryFee,
                                        extraChargeLoading: extraChargeLoading,
                                        deliveryFee: deliveryFee
                                    }) : extraChargeLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_OrderCalculationShimmer__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {})
                                ]
                            })
                        }),
                        currentModuleType === "pharmacy" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomPaperBigCard */ .iD, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Prescription_SinglePrescriptionUpload__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z, {
                                t: t,
                                handleImageUpload: handleImageUpload
                            })
                        })
                    ]
                })
            }),
            orderType === "delivery" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                md: 7,
                xs: 12,
                children: zoneData && storeData && paymentMethodShow()
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                item: true,
                md: 12,
                xs: 12,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PlaceOrder__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                    placeOrder: placeOrder,
                    orderLoading: orderLoading,
                    zoneData: zoneData,
                    orderType: orderType
                })
            })
        ]
    });
};
ItemCheckout.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItemCheckout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 71923:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _typographies_H1__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74485);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _DeliveryInfo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(15245);
/* harmony import */ var _Billing__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(96542);
/* harmony import */ var _PaymentMethod__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97993);
/* harmony import */ var _api_manage_hooks_react_query_google_api_useGetDistance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(36498);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _api_manage_hooks_react_query_order_place_useOrderPlace__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(74093);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86201);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22021);
/* harmony import */ var _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(61176);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(55496);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(81261);
/* harmony import */ var _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8142);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_typographies_H1__WEBPACK_IMPORTED_MODULE_3__, _DeliveryInfo__WEBPACK_IMPORTED_MODULE_6__, _Billing__WEBPACK_IMPORTED_MODULE_7__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_google_api_useGetDistance__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_order_place_useOrderPlace__WEBPACK_IMPORTED_MODULE_11__, react_hot_toast__WEBPACK_IMPORTED_MODULE_12__, i18next__WEBPACK_IMPORTED_MODULE_13__, _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_14__, _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_16__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_18__]);
([_typographies_H1__WEBPACK_IMPORTED_MODULE_3__, _DeliveryInfo__WEBPACK_IMPORTED_MODULE_6__, _Billing__WEBPACK_IMPORTED_MODULE_7__, _PaymentMethod__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_google_api_useGetDistance__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_order_place_useOrderPlace__WEBPACK_IMPORTED_MODULE_11__, react_hot_toast__WEBPACK_IMPORTED_MODULE_12__, i18next__WEBPACK_IMPORTED_MODULE_13__, _api_manage_MainApi__WEBPACK_IMPORTED_MODULE_14__, _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_16__, _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__, _api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const ParcelCheckout = ()=>{
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.configData);
    const { parcelInfo  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.parcelInfoData);
    const { profileInfo  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.profileInfo);
    const [address, setAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const [deliveryTip, setDeliveryTip] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [paymentMethod, setPaymentMethod] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [paidBy, setPaidBy] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("sender");
    const { parcelCategories  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.parcelCategories);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const [zoneIdEnabled, setZoneIdEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [currentZoneId, setCurrentZoneId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const receiverLoacation = {
        lat: parcelInfo?.receiverLocations?.lat,
        lng: parcelInfo?.receiverLocations?.lng
    };
    const { data: zoneData  } = (0,_api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)(receiverLoacation, zoneIdEnabled);
    const { data , refetch  } = (0,_api_manage_hooks_react_query_google_api_useGetDistance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(parcelInfo?.senderLocations, parcelInfo?.receiverLocations);
    const tempDistance = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__/* .handleDistance */ .NY)(data?.data?.rows?.[0]?.elements, {
        latitude: parcelInfo?.receiverLocations?.latitude,
        longitude: parcelInfo?.receiverLocations?.longitude
    }, address);
    const { data: extraCharge , isLoading: extraChargeLoading , refetch: extraChargeRefetch  } = (0,_api_manage_hooks_react_query_order_place_useGetVehicleCharge__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)({
        tempDistance
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (data) {
            extraChargeRefetch();
        }
    }, [
        data
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        refetch();
    }, [
        parcelInfo
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const currentLatLng = JSON.parse(localStorage.getItem("currentLatLng"));
        const location = localStorage.getItem("location");
        const zoneId = JSON.parse(localStorage.getItem("zoneid"));
        setCurrentZoneId(zoneId?.[0]);
        setAddress({
            ...currentLatLng,
            latitude: currentLatLng?.lat,
            longitude: currentLatLng?.lng,
            address: location,
            address_type: "Selected Address"
        });
    }, []);
    const parcelDeliveryFree = ()=>{
        let convertedDistance = (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__/* .handleDistance */ .NY)(data?.rows[0]?.elements, parcelInfo?.senderLocations, parcelInfo?.receiverLocations);
        if (parcelCategories?.parcel_per_km_shipping_charge) {
            let deliveryFee = convertedDistance * parcelCategories?.parcel_per_km_shipping_charge;
            if (deliveryFee > parcelCategories?.parcel_minimum_shipping_charge) {
                return deliveryFee + extraCharge;
            } else {
                return parcelCategories?.parcel_minimum_shipping_charge + extraCharge;
            }
        } else {
            let deliveryFee1 = convertedDistance * configData?.parcel_per_km_shipping_charge;
            if (deliveryFee1 > configData?.parcel_minimum_shipping_charge) {
                return deliveryFee1 + extraCharge;
            } else {
                return configData?.parcel_minimum_shipping_charge + extraCharge;
            }
        }
    };
    const receiverDetails = JSON.stringify({
        id: null,
        address_type: "others",
        contact_person_number: parcelInfo?.receiverPhone,
        address: parcelInfo?.receiverAddress,
        additional_address: null,
        latitude: parcelInfo?.receiverLocations?.lat,
        longitude: parcelInfo?.receiverLocations?.lng,
        zone_id: zoneData?.zone_id[1],
        zone_ids: null,
        _method: null,
        contact_person_name: parcelInfo?.receiverName,
        road: parcelInfo?.road,
        house: parcelInfo?.house,
        floor: parcelInfo?.floor
    });
    const orderMutationObject = {
        ...address,
        cart: [],
        order_amount: parcelDeliveryFree() + Number(deliveryTip),
        order_type: "parcel",
        payment_method: paymentMethod,
        distance: (0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_17__/* .handleDistance */ .NY)(data?.rows[0]?.elements, parcelInfo?.senderLocations, parcelInfo?.receiverLocations),
        discount_amount: 0,
        tax_amount: 0,
        receiver_details: receiverDetails,
        parcel_category_id: parcelCategories?.id,
        charge_payer: paidBy,
        dm_tips: deliveryTip
    };
    const { data: order , isLoading , mutate: orderMutation  } = (0,_api_manage_hooks_react_query_order_place_useOrderPlace__WEBPACK_IMPORTED_MODULE_11__/* .useOrderPlace */ .P)();
    const orderPlace = ()=>{
        if (paidBy === "sender") {
            const handleSuccess = (res)=>{
                if (res) {
                    if (paymentMethod === "digital_payment") {
                        localStorage.setItem("totalAmount", res?.total_ammount);
                        const callBackUrl = `${window.location.origin}/order?order_id=${res?.order_id}&total=${res?.total_ammount}`;
                        const url = `${_api_manage_MainApi__WEBPACK_IMPORTED_MODULE_14__/* .baseUrl */ .F}/payment-mobile?order_id=${res?.order_id}&customer_id=${profileInfo?.id}&callback=${callBackUrl}`;
                        router.push(url, undefined, {
                            shallow: true
                        });
                    } else if (paymentMethod === "wallet") {
                        if (Number(profileInfo?.wallet_balance) < Number(parcelDeliveryFree())) {
                            react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_13__.t)("Wallet balance is below total amount."), {
                                id: "wallet",
                                position: "bottom-right"
                            });
                        } else {
                            react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(res?.message);
                            router.push({
                                pathname: "/order",
                                query: {
                                    order_id: res?.order_id,
                                    total: res?.total_ammount
                                }
                            }, undefined, {
                                shallow: true
                            });
                        }
                    } else {
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(res?.message);
                        router.push({
                            pathname: "/order",
                            query: {
                                order_id: res?.order_id,
                                total: res?.total_ammount
                            }
                        }, undefined, {
                            shallow: true
                        });
                    }
                }
            };
            orderMutation(orderMutationObject, {
                onSuccess: handleSuccess,
                onError: (error)=>{
                    error?.response?.data?.errors?.forEach((item)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error(item.message, {
                            position: "bottom-right"
                        }));
                }
            });
        } else {
            if (paymentMethod === "cash_on_delivery") {
                const handleSuccess1 = (res)=>{
                    if (res) {
                        if (paymentMethod === "digital_payment") {
                            localStorage.setItem("totalAmount", res?.total_ammount);
                            const callBackUrl = `${window.location.origin}/order?order_id=${res?.order_id}&total=${res?.total_ammount}`;
                            const url = `${_api_manage_MainApi__WEBPACK_IMPORTED_MODULE_14__/* .baseUrl */ .F}/payment-mobile?order_id=${res?.order_id}&customer_id=${profileInfo?.id}&callback=${callBackUrl}`;
                            router.push(url, undefined, {
                                shallow: true
                            });
                        } else if (paymentMethod === "wallet") {
                            if (Number(profileInfo?.wallet_balance) < Number(parcelDeliveryFree())) {
                                react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_13__.t)("Wallet balance is below total amount."), {
                                    id: "wallet",
                                    position: "bottom-right"
                                });
                            } else {
                                react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(res?.message);
                                router.push({
                                    pathname: "/order",
                                    query: {
                                        order_id: res?.order_id,
                                        total: res?.total_ammount
                                    }
                                }, undefined, {
                                    shallow: true
                                });
                            }
                        } else {
                            react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(res?.message);
                            router.push({
                                pathname: "/order",
                                query: {
                                    order_id: res?.order_id,
                                    total: res?.total_ammount
                                }
                            }, undefined, {
                                shallow: true
                            });
                        }
                    }
                };
                orderMutation(orderMutationObject, {
                    onSuccess: handleSuccess1,
                    onError: (error)=>{
                        error?.response?.data?.errors?.forEach((item)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error(item.message, {
                                position: "bottom-right"
                            }));
                    }
                });
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_13__.t)("Without any payment method, you can not place the order."));
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        paddingBottom: {
            sm: "20px",
            md: "80px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                paddingBottom: "20px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    text: "Checkout"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                    container: true,
                    spacing: 4,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                            item: true,
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DeliveryInfo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                configData: configData,
                                parcelInfo: parcelInfo,
                                parcelCategories: parcelCategories
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                            item: true,
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Billing__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                deliveryTip: deliveryTip,
                                setDeliveryTip: setDeliveryTip,
                                paidBy: paidBy,
                                setPaidBy: setPaidBy,
                                data: data,
                                parcelDeliveryFree: parcelDeliveryFree,
                                zoneData: {
                                    data: zoneData
                                },
                                senderLocation: parcelInfo?.senderLocations,
                                receiverLocation: parcelInfo?.receiverLocations,
                                configData: configData
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Grid, {
                            item: true,
                            xs: 12,
                            sm: 12,
                            md: 4,
                            children: !!currentZoneId && zoneData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentMethod__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                setPaymentMethod: setPaymentMethod,
                                paymentMethod: paymentMethod,
                                paidBy: paidBy,
                                isLoading: isLoading,
                                orderPlace: orderPlace,
                                zoneData: {
                                    data: zoneData
                                },
                                configData: configData,
                                storeZoneId: currentZoneId
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(ParcelCheckout));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 72805:
/***/ ((module) => {

module.exports = require("@emotion/react");

/***/ }),

/***/ 47915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 66146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 4195:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBackIos");

/***/ }),

/***/ 95780:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBackIosNew");

/***/ }),

/***/ 61883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForward");

/***/ }),

/***/ 91658:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 1575:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowLeft");

/***/ }),

/***/ 7902:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowRight");

/***/ }),

/***/ 33060:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowRightAlt");

/***/ }),

/***/ 7521:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChatBubbleOutline");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Check");

/***/ }),

/***/ 76756:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckBoxOutlined");

/***/ }),

/***/ 66741:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckCircle");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 44486:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloudUpload");

/***/ }),

/***/ 29605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 99520:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Create");

/***/ }),

/***/ 83188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 8690:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Error");

/***/ }),

/***/ 27372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 6910:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 25967:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 43866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterList");

/***/ }),

/***/ 50682:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Fullscreen");

/***/ }),

/***/ 64107:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FullscreenExit");

/***/ }),

/***/ 15594:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GpsFixed");

/***/ }),

/***/ 49262:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GridViewRounded");

/***/ }),

/***/ 73467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 60357:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ImportContacts");

/***/ }),

/***/ 64845:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 57834:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowLeft");

/***/ }),

/***/ 70547:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 99881:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 37236:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardDoubleArrowDown");

/***/ }),

/***/ 45048:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardDoubleArrowRight");

/***/ }),

/***/ 96866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LibraryBooks");

/***/ }),

/***/ 50550:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalPhone");

/***/ }),

/***/ 12906:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 40399:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LockOutlined");

/***/ }),

/***/ 89801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 84552:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Loyalty");

/***/ }),

/***/ 14272:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Map");

/***/ }),

/***/ 63365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 79667:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PersonOutlineOutlined");

/***/ }),

/***/ 15214:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Place");

/***/ }),

/***/ 19509:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Remove");

/***/ }),

/***/ 15642:
/***/ ((module) => {

module.exports = require("@mui/icons-material/RemoveRedEye");

/***/ }),

/***/ 49426:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Room");

/***/ }),

/***/ 38017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 39823:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SendToMobile");

/***/ }),

/***/ 10032:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6408:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartCheckout");

/***/ }),

/***/ 22749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 72548:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartRounded");

/***/ }),

/***/ 19766:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SmsRounded");

/***/ }),

/***/ 77849:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Star");

/***/ }),

/***/ 33378:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StarRate");

/***/ }),

/***/ 9001:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Wallet");

/***/ }),

/***/ 65342:
/***/ ((module) => {

module.exports = require("@mui/icons-material/WarningAmber");

/***/ }),

/***/ 86072:
/***/ ((module) => {

module.exports = require("@mui/lab");

/***/ }),

/***/ 76829:
/***/ ((module) => {

module.exports = require("@mui/lab/LoadingButton");

/***/ }),

/***/ 65692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 83882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 53819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 94960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 8611:
/***/ ((module) => {

module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 29404:
/***/ ((module) => {

module.exports = require("@mui/material/DialogActions");

/***/ }),

/***/ 52468:
/***/ ((module) => {

module.exports = require("@mui/material/DialogTitle");

/***/ }),

/***/ 73646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 45634:
/***/ ((module) => {

module.exports = require("@mui/material/Fade");

/***/ }),

/***/ 68891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 88185:
/***/ ((module) => {

module.exports = require("@mui/material/FormControlLabel");

/***/ }),

/***/ 6354:
/***/ ((module) => {

module.exports = require("@mui/material/FormHelperText");

/***/ }),

/***/ 67934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 85246:
/***/ ((module) => {

module.exports = require("@mui/material/Link");

/***/ }),

/***/ 94192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 834:
/***/ ((module) => {

module.exports = require("@mui/material/ListItem");

/***/ }),

/***/ 31011:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 78315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 48125:
/***/ ((module) => {

module.exports = require("@mui/material/Menu");

/***/ }),

/***/ 29271:
/***/ ((module) => {

module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 55374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 76563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 40441:
/***/ ((module) => {

module.exports = require("@mui/material/Skeleton");

/***/ }),

/***/ 27163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 18442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 69868:
/***/ ((module) => {

module.exports = require("@mui/material/useMediaQuery");

/***/ }),

/***/ 69484:
/***/ ((module) => {

module.exports = require("@mui/styles");

/***/ }),

/***/ 97986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 82433:
/***/ ((module) => {

module.exports = require("@react-google-maps/api");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 46517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 32245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 13332:
/***/ ((module) => {

module.exports = require("moment/moment");

/***/ }),

/***/ 53918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 11022:
/***/ ((module) => {

module.exports = require("react-geolocated");

/***/ }),

/***/ 50801:
/***/ ((module) => {

module.exports = require("react-image-magnify");

/***/ }),

/***/ 25452:
/***/ ((module) => {

module.exports = require("react-phone-input-2");

/***/ }),

/***/ 61175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 38096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 94172:
/***/ ((module) => {

module.exports = require("simplebar-react");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 99648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 23745:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 33512:
/***/ ((module) => {

module.exports = import("firebase/messaging");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 69915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 86201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,676,8889,5269,7113,4121,8861,9240,4369,801,6941,6672,7595,7787,4349], () => (__webpack_exec__(86711)));
module.exports = __webpack_exports__;

})();